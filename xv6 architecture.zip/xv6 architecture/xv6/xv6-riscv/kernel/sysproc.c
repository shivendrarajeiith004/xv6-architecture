#include "types.h"
#include "riscv.h"
#include "defs.h"
#include "param.h"
#include "memlayout.h"
#include "spinlock.h"
#include "proc.h"

uint64
sys_exit(void)
{
  int n;
  argint(0, &n);
  exit(n);
  return 0;  // not reached
}

uint64
sys_getpid(void)
{
  return myproc()->pid;
}

uint64
sys_fork(void)
{
  return fork();
}

uint64
sys_wait(void)
{
  uint64 p;
  argaddr(0, &p);
  return wait(p);
}

uint64
sys_sbrk(void)
{
  uint64 addr;
  int n;

  argint(0, &n);
  addr = myproc()->sz;
  // myproc()->sz+=n;
  if(growproc(n) < 0)
    return -1;
  // if(n<0)uvmdealloc(myproc()->pagetable,addr,myproc()->sz);
   return addr;
}

uint64
sys_sleep(void)
{
  int n;
  uint ticks0;

  argint(0, &n);
  acquire(&tickslock);
  ticks0 = ticks;
  while(ticks - ticks0 < n){
    if(killed(myproc())){
      release(&tickslock);
      return -1;
    }
    sleep(&ticks, &tickslock);
  }
  release(&tickslock);
  return 0;
}

uint64
sys_kill(void)
{
  int pid;

  argint(0, &pid);
  return kill(pid);
}

// return how many clock tick interrupts have occurred
// since start.
uint64
sys_uptime(void)
{
  uint xticks;

  acquire(&tickslock);
  xticks = ticks;
  release(&tickslock);
  return xticks;
}
int i_global = 0;
int nxt_pagetable;
int counter;
uint64 tmp;
/*
uint64
sys_pgtPrint(pagetable_t pagetable){
  //printf("testing...\n");
  if (i_global == 0)
  {
    printf("print pagetable : %p\n", pagetable);
    nxt_pagetable = 0;
    counter = 0;
    i_global++;
  }

  for (int i = 0; i < 512; i++)
  {
    pte_t table_entry = pagetable[i];

    if (table_entry & PTE_V)
    {
      printf("%d: Virtual page address : %p Physical page address : %p\n", i, table_entry, PTE2PA(table_entry));
      counter++;
      if ((table_entry & (PTE_R | PTE_W)) == 0)
      {
        uint64 nxt_level = PTE2PA(table_entry);
        nxt_pagetable++;

        uint temp = sys_pgtPrint((pagetable_t)nxt_level);
        temp++;
      }
    }
  }

  return 0;
}
*/

/*
uint64
sys_pgtPrint(pagetable_t pagetable)
{
  
  struct proc *curproc = myproc();
  if (curproc == 0)
    return -1; // No process found

  pte_t *pgtable = curproc->pagetable;
  if (pgtable == 0)
    return -1; // No page table found

  for (int i = 0; i < 512; i++) {
    pte_t pte = pgtable[i];
    if (pte & PTE_V) {
      uint64 vaddr = PGROUNDDOWN(i * PGSIZE);
      uint64 paddr = (pte & TRAPFRAME) | (vaddr & 0xFFF);
      printf("PTE No: %d, Virtual page address: 0x%x, Physical page address: 0x%x\n", i, vaddr, paddr);
    }
  }
  return 22;
  
 //printf("GANJA");
 //return 0;
}
*/

//actual code
uint64
sys_pgtPrint(void){
  vmprintsupport(myproc()->pagetable);
  return 0;
}
#include "kernel/types.h"
#include "kernel/stat.h"
#include "user/user.h"
int main() {
    int pipe1[2], pipe2[2];
    char ping = 'p'; // BYTE THAT IS SHARED
    
    // CREATING PIPES
    if (pipe(pipe1) < 0 || pipe(pipe2) < 0) {
        fprintf(2, "Error\n");
        exit(2);
    }
	//CREATING CHILD AND PARENT PROCESS
    int pid = fork();
    if (pid < 0) {
        fprintf(2, "Error: Fork \n");
        exit(1);
    }
    
    if (pid == 0) { // Child process
        close(pipe1[1]); // Close write pipe1
        close(pipe2[0]); // Close read  pipe2
        
        char recMessage;
        read(pipe1[0], &recMessage, sizeof(recMessage)); //  Parent Read
        printf("%d: received Message ping\n", getpid());
        
        write(pipe2[1], &recMessage, sizeof(recMessage)); // Write to parent
        exit(2);
    } else { // Parent 
        close(pipe1[0]); // Close read pipe1
        close(pipe2[1]); // Close write pipe2
        
        write(pipe1[1], &ping, sizeof(ping)); // Write to child
        
        char recMessage;
        read(pipe2[0], &recMessage, sizeof(recMessage)); // Read from child
        printf("%d: received Message pong\n", getpid());
        
        //wait(NULL);
        exit(1);
    }
}

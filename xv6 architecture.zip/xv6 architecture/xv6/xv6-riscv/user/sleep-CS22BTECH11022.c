#include "kernel/types.h"
#include "kernel/stat.h"
#include "user/user.h"

int main(int argc, char * argv[]){
    if(argc != 2){ //used from rm.c
    fprintf(2, "Usage: sleep \n");//WRITING TO ERROR FILE
    exit(2); //EXITING..
  }
    int numTick = atoi(argv[1]); // CONVERTING COMMAND LINE ARGS TO INT
    //sleep(numTick);
    if (numTick <= 0) // AVOIDING EXCEPTIONAL CASES
    {
        fprintf(2,"Error ! Number of ticks in invalid\n");   //ERROR MESSAGES
        exit(2); // EXITING CODE
    }
    else{ 
    	printf("Number of Ticks : %d\n", numTick); // PRINTING NUMBER OF TICKS
        sleep(numTick * 10); // AS PER TA GUIDELINES
    }
    exit(0); // EXITING CODE
    //return 0;
}

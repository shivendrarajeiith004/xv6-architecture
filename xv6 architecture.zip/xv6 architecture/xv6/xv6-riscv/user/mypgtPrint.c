#include "kernel/types.h"
#include "kernel/stat.h"
#include "user/user.h"

int arrGlobal[10000];
int main(){
    printf("printing from mypgtPrint\n");
    pgtPrint();
    exit(1);
}

#include "kernel/types.h"
#include "kernel/stat.h"
#include "user/user.h"
#include "kernel/fcntl.h"
//Buffer size
#define MAX_BUF_SIZE 1024 // This is block size
int main(int argc, char *argv[]) {
    char buf[MAX_BUF_SIZE];
    int n;
    struct stat st;
    if (argc != 3) {
        printf("create_file <fileName> <fileSize>\n");
        exit(1);
    }
    //taking arguments from command line
    char *fileName = argv[1];
    int fileSize = atoi(argv[2]); 

    // Create file using open call
    int fd = open(fileName, O_CREATE | O_WRONLY);
    if (fd < 0) {
        printf("Failed to create/open file\n");
        exit(1);
    }

    // Writing roll number to file
    char rollNo[14] = {'C', 'S', '2', '2', 'B', 'T', 'E', 'C', 'H', '1', '1', '0', '2', '2'}; 
    for (int i = 0; i < fileSize; i++) {
        write(fd, rollNo+(i%14), 1);
    }
    close(fd);
    if (stat(fileName, &st) < 0) {
        printf("Failed to get file information\n");
        exit(1);
    }
    printf("File created successfully!\n iNode number: %d\n", st.ino);
    printf("contents:\n");
    while ((n = read(open(fileName, O_RDONLY), buf, sizeof(buf))) > 0) {
        write(1, buf, n);
    }
    printf("\n");
    printf("disk blocks: ");
    for (int i = 0; i < st.size / 1024 + 1; i++) {
        printf("%d ", i);
    }
    printf("\n");
    exit(0);
}